# 🌍 Comprehensive Travel Planner

An intelligent, AI-powered travel planning application that generates complete, personalized trip plans with hotel recommendations, restaurant guides, budgets, packing lists, and more!

## ✨ Features

### What You Get:
1. **Day-by-Day Itinerary** - Full plans for every day with timings, fees, and activity details
2. **Top 5 Hotel Recommendations** - Budget to luxury options with prices and reviews
3. **Restaurant Guide** - Breakfast, lunch, and dinner spots for each day with addresses and must-try dishes
4. **Complete Budget Breakdown** - Flights, accommodation, food, activities, transport, and more
5. **Smart Packing List** - Tailored to destination, season, and trip type
6. **Local Transport Guide** - Apps, metro passes, taxi fares, and scam alerts
7. **Cultural Etiquette & Safety Tips** - Dress codes, tipping culture, areas to avoid
8. **Top 3 Hidden Gems** - Places tourists miss but locals love
9. **Pre-Trip Checklist** - 2-week countdown to departure
10. **Emergency Information** - Hospitals, pharmacies, embassies, emergency numbers
11. **Weather & Packing Tips** - What to expect and what to wear
12. **Money & Payments Guide** - ATM tips, currency exchange, scam alerts

## 🚀 Quick Start

### Installation

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start the Server**
   ```bash
   npm start
   ```
   Or in development mode:
   ```bash
   npm run dev
   ```

3. **Open Your Browser**
   ```
   http://localhost:3000
   ```

## 📋 How to Use

1. **Fill Out the Form**
   - Select your destination (Paris, Tokyo, Dubai, or London)
   - Enter your departure city
   - Choose your dates
   - Specify number of travelers and children (if any)
   - Set your budget level and total budget
   - Choose accommodation type and star rating
   - Select activity preferences and dining style
   - Provide health & safety information

2. **Generate Your Plan**
   - Click "Generate My Complete Trip Plan 🚀"
   - The app will create a comprehensive, personalized itinerary

3. **Review & Customize**
   - Browse through all 12 sections
   - Print your plan using the Print button
   - Download as PDF using the Download button
   - Go back to form to create a new plan

## 📍 Supported Destinations

Currently supports detailed plans for:
- **Paris, France** - Culture, art, fine dining, romance
- **Tokyo, Japan** - Modern culture, temples, amazing food
- **Dubai, UAE** - Luxury, desert experiences, shopping
- **London, UK** - History, museums, diverse neighborhoods

*More destinations can be easily added by extending the `travelData` object in `travelPlanner.js`*

## 💻 Project Structure

```
travel-planner/
├── server.js                    # Express server
├── travelPlanner.js            # Trip plan generation logic
├── package.json                # Project dependencies
├── public/
│   ├── index.html              # Main HTML form
│   ├── style.css               # Styling
│   ├── script.js               # Frontend logic
└── .gitignore                  # Git ignore file
```

## 🎨 Customization

### Add a New Destination

1. Open `travelPlanner.js`
2. Add a new entry to `travelData.destinations` with the destination key (e.g., 'bangkok'):
   ```javascript
   destinations: {
       bangkok: {
           country: 'Thailand',
           currency: 'THB',
           safetyScore: 7.5,
           emergencyNumber: '191',
           // ... add all required fields
       }
   }
   ```
3. Add the destination option to the HTML select dropdown in `public/index.html`

### Modify Budgets/Prices

- Edit the hotel prices in `travelPlanner.js` → `travelData.destinations[destination].hotels`
- Adjust flight prices in the `flights` object
- Change restaurant prices in the `restaurants` object

## 🌐 Browser Compatibility

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (responsive design)

## 📱 Features

### Responsive Design
- Works perfectly on desktop, tablet, and mobile
- Mobile-optimized form and output display
- Touch-friendly buttons

### Print & Export
- **Print to PDF** - Use browser print function (Ctrl+P / Cmd+P)
- **Back Button** - Return to form to create new plans
- **Professional Layout** - Print-optimized styling

## 🔧 Technologies Used

- **Backend**: Node.js + Express.js
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Data Format**: JSON

## 📦 Dependencies

```json
{
  "express": "^4.18.2",
  "body-parser": "^1.20.2"
}
```

## 🚀 Deployment

### Heroku
```bash
# Create Procfile
echo "web: node server.js" > Procfile

# Deploy
heroku create
git push heroku main
```

### Local Network Access
```bash
# In server.js, change:
app.listen(PORT, 'localhost', ...)
# To:
app.listen(PORT, '0.0.0.0', ...)

# Then access from another device:
http://YOUR_IP:3000
```

## 💡 Future Enhancements

- [ ] Add more destinations (Barcelona, NYC, Bali, etc.)
- [ ] Real-time hotel & flight price integration
- [ ] User accounts to save plans
- [ ] PDF export without print screen
- [ ] Weather API integration
- [ ] Currency conversion API
- [ ] Google Maps integration
- [ ] Recommendation engine based on traveler profile
- [ ] Multi-language support
- [ ] Mobile app version

## 📝 Tips for Best Results

1. **Be Specific** - Fill in all fields accurately for better recommendations
2. **Budget Realistically** - The planner will distribute your budget across categories
3. **Consider Season** - Weather affects packing and activity recommendations
4. **Check Visas Early** - Visa processing can take 4-8 weeks
5. **Book in Advance** - Hotels and flights are cheaper when booked 2-3 months ahead

## ❓ FAQ

**Q: Can I modify the recommendations?**
A: Yes! The app provides starting points. Customize any activity, restaurant, or hotel based on your preferences.

**Q: How accurate are the prices?**
A: Prices are estimates based on 2024-2025 data. Always verify current prices when booking.

**Q: Can I use this offline?**
A: The form works on your computer. You need internet to generate plans initially, but the output can be printed/saved offline.

**Q: Is my data saved?**
A: No. Plans are generated on-demand. Close your browser and all data is gone (by design for privacy).

## 📧 Support

For questions or suggestions, feel free to reach out or create an issue.

## 📄 License

MIT License - Feel free to use and modify for personal or commercial projects.

---

**Made with ❤️ for travelers**

Happy travels! 🌍✈️🗺️
