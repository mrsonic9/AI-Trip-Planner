// Travel Planner Logic - Generates comprehensive trip plans

const travelData = {
  destinations: {
    paris: {
      country: 'France',
      currency: 'EUR',
      safetyScore: 8.5,
      emergencyNumber: '112',
      visaInfo: 'EU/Schengen citizens: No visa. Others: Check Schengen requirements',
      hospitals: ['Hôpital de la Pitié-Salpêtrière', 'Hôpital Saint-Louis'],
      flights: { avgPrice: 150, carrier: 'Air France, Ryanair, Lufthansa' },
      hotels: {
        budget: { name: 'Les Plumes Hotel', price: 80, stars: 3, addr: '16 Rue Amelie, Paris' },
        midrange: { name: 'Le Marais Boutique Hotel', price: 150, stars: 4, addr: '23 Rue de Sevigne, Paris' },
        luxury: { name: 'Plaza Athénée', price: 400, stars: 5, addr: '25 Avenue Montaigne, Paris' }
      },
      activities: [
        { name: 'Eiffel Tower', fee: 18, hours: '9:00-23:45', desc: 'Iconic iron monument', type: 'must-see' },
        { name: 'Louvre Museum', fee: 17, hours: '9:00-18:00', desc: 'World\'s largest art museum', type: 'must-see' },
        { name: 'Notre-Dame Cathedral', fee: 0, hours: '8:00-18:45', desc: 'Gothic masterpiece', type: 'must-see' },
        { name: 'Arc de Triomphe', fee: 13, hours: '10:00-22:30', desc: 'Monumental arch', type: 'must-see' },
        { name: 'Versailles Palace', fee: 20, hours: '9:00-18:30', desc: 'Royal palace & gardens', type: 'optional' }
      ],
      restaurants: {
        breakfast: [
          { name: 'Café de Flore', cuisine: 'French', price: 15, dish: 'Croissant & Café', addr: '172 Boulevard Saint-Germain' },
          { name: 'L\'Artisan Boulanger', cuisine: 'Bakery', price: 12, dish: 'Pain au Chocolat', addr: '75 Rue des Martyrs' }
        ],
        lunch: [
          { name: 'L\'As du Fallafel', cuisine: 'Middle Eastern', price: 12, dish: 'Fallafel Wrap', addr: '34 Rue des Rosiers' },
          { name: 'Bouchon de François', cuisine: 'French', price: 20, dish: 'Coq au Vin', addr: '8 Rue Monsieur le Prince' }
        ],
        dinner: [
          { name: 'Le Jules Verne', cuisine: 'French Fine Dining', price: 80, dish: 'Duck Confit', addr: 'Eiffel Tower' },
          { name: 'L\'Astrance', cuisine: 'Contemporary French', price: 100, dish: 'Tasting Menu', addr: '4 Rue Beethoven' }
        ]
      },
      weather: {
        spring: 'Pleasant, 10-15°C, possible rain',
        summer: 'Warm, 20-25°C, crowded',
        fall: 'Cool, 10-15°C, beautiful',
        winter: 'Cold, 2-7°C, fewer crowds'
      }
    },
    tokyo: {
      country: 'Japan',
      currency: 'JPY',
      safetyScore: 9.5,
      emergencyNumber: '110',
      visaInfo: 'Many countries get 90 days visa-free. Check specific requirements',
      hospitals: ['Keio University Hospital', 'University of Tokyo Hospital'],
      flights: { avgPrice: 800, carrier: 'JAL, ANA, Emirates' },
      hotels: {
        budget: { name: 'Capsule Land', price: 35, stars: 2, addr: 'Shinjuku, Tokyo' },
        midrange: { name: 'Shinjuku Washington Hotel', price: 120, stars: 4, addr: '2-4-1 Yotsuya, Shinjuku' },
        luxury: { name: 'The Peninsula Tokyo', price: 500, stars: 5, addr: '1-8-1 Yurakucho, Chiyoda' }
      },
      activities: [
        { name: 'Senso-ji Temple', fee: 0, hours: '6:00-17:00', desc: 'Tokyo\'s oldest temple', type: 'must-see' },
        { name: 'Meiji Shrine', fee: 0, hours: '24/7', desc: 'Serene Shinto shrine', type: 'must-see' },
        { name: 'Shibuya Crossing', fee: 0, hours: '24/7', desc: 'World\'s busiest crossing', type: 'must-see' },
        { name: 'Tokyo National Museum', fee: 10, hours: '9:30-17:00', desc: 'Japanese art & history', type: 'optional' }
      ],
      restaurants: {
        breakfast: [
          { name: 'Rikuro\'s Okonomiyaki House', cuisine: 'Japanese', price: 10, dish: 'Okonomiyaki', addr: 'Dotonbori' },
          { name: 'Tsukiji Outer Market', cuisine: 'Sushi', price: 15, dish: 'Fresh Sushi', addr: 'Tsukiji Market' }
        ],
        lunch: [
          { name: 'Ichiran Ramen', cuisine: 'Ramen', price: 12, dish: 'Tonkotsu Ramen', addr: 'Multiple locations' },
          { name: 'Ginza Sushi', cuisine: 'Sushi', price: 35, dish: 'Omakase', addr: '4-2-15 Ginza' }
        ],
        dinner: [
          { name: 'Sukiyabashi Jiro', cuisine: 'Sushi Fine Dining', price: 150, dish: '3-Michelin Omakase', addr: 'Ginza' },
          { name: 'Nabezo', cuisine: 'Hot Pot', price: 40, dish: 'Wagyu Hot Pot', addr: 'Roppongi' }
        ]
      },
      weather: {
        spring: 'Mild, 10-20°C, cherry blossoms',
        summer: 'Hot & humid, 25-35°C',
        fall: 'Cool, 15-25°C, beautiful',
        winter: 'Cold, 0-10°C, dry'
      }
    },
    dubai: {
      country: 'UAE',
      currency: 'AED',
      safetyScore: 8.8,
      emergencyNumber: '999',
      visaInfo: 'Many nationalities get 30-90 days on arrival',
      hospitals: ['American Hospital Dubai', 'NMC Royal Hospital'],
      flights: { avgPrice: 200, carrier: 'Emirates, Flydubai, Air Arabia' },
      hotels: {
        budget: { name: 'Time Hotel Downtown', price: 70, stars: 3, addr: 'Downtown Dubai' },
        midrange: { name: 'JW Marriott Emirates Hills', price: 180, stars: 5, addr: 'Emirates Hills' },
        luxury: { name: 'Burj Al Arab', price: 800, stars: 7, addr: 'Jumeirah Beach' }
      },
      activities: [
        { name: 'Burj Khalifa', fee: 25, hours: '8:00-23:00', desc: 'World\'s tallest building', type: 'must-see' },
        { name: 'Dubai Mall', fee: 0, hours: '10:00-22:00', desc: 'Massive shopping mall', type: 'must-see' },
        { name: 'Desert Safari', fee: 60, hours: '16:00-22:00', desc: 'Dunes & cultural show', type: 'must-see' },
        { name: 'Palm Jumeirah', fee: 0, hours: '24/7', desc: 'Iconic artificial island', type: 'optional' }
      ],
      restaurants: {
        breakfast: [
          { name: 'Zaroob', cuisine: 'Levantine', price: 12, dish: 'Manakish', addr: 'Al Wasl Road' },
          { name: 'Al Reef Bakery', cuisine: 'Middle Eastern', price: 8, dish: 'Cheese Manoush', addr: 'Multiple locations' }
        ],
        lunch: [
          { name: 'Al Mallah Grills', cuisine: 'Middle Eastern', price: 15, dish: 'Shawarma', addr: 'Satwa' },
          { name: 'Nobu Dubai', cuisine: 'Japanese Fusion', price: 80, dish: 'Black Cod Miso', addr: 'Atlantis The Palm' }
        ],
        dinner: [
          { name: 'At.mosphere (Burj Khalifa)', cuisine: 'Fine Dining', price: 150, dish: 'Tasting Menu', addr: 'Burj Khalifa' },
          { name: 'Zuma', cuisine: 'Japanese', price: 100, dish: 'Wagyu & Sushi', addr: 'DIFC' }
        ]
      },
      weather: {
        spring: 'Hot, 30-40°C',
        summer: 'Scorching, 40-50°C, avoid',
        fall: 'Very hot, 35-45°C',
        winter: 'Pleasant, 20-28°C, best time'
      }
    },
    london: {
      country: 'UK',
      currency: 'GBP',
      safetyScore: 8.0,
      emergencyNumber: '999',
      visaInfo: 'Most nationalities get 6 months visa-free (post-Brexit)',
      hospitals: ['St Thomas\' Hospital', 'University College Hospital'],
      flights: { avgPrice: 120, carrier: 'British Airways, Ryanair, EasyJet' },
      hotels: {
        budget: { name: 'Premier Inn London', price: 80, stars: 3, addr: 'Leicester Square' },
        midrange: { name: 'The Standard London', price: 200, stars: 4, addr: 'Shoreditch' },
        luxury: { name: 'The Savoy', price: 600, stars: 5, addr: 'Strand, West End' }
      },
      activities: [
        { name: 'Big Ben & Parliament', fee: 0, hours: 'Exterior 24/7', desc: 'Gothic architecture', type: 'must-see' },
        { name: 'Tower of London', fee: 30, hours: '9:00-17:00', desc: 'Medieval fortress & crown jewels', type: 'must-see' },
        { name: 'British Museum', fee: 0, hours: '10:00-17:30', desc: 'World history artifacts', type: 'must-see' },
        { name: 'London Eye', fee: 35, hours: '11:00-18:00', desc: 'Giant observation wheel', type: 'optional' }
      ],
      restaurants: {
        breakfast: [
          { name: 'Granger & Co', cuisine: 'Modern British', price: 18, dish: 'Ricotta Hotcakes', addr: 'King\'s Cross' },
          { name: 'Breakfast Club', cuisine: 'Café', price: 12, dish: 'Full English', addr: 'Soho' }
        ],
        lunch: [
          { name: 'Fish & Chips Shop', cuisine: 'British', price: 15, dish: 'Cod & Chips', addr: 'Multiple locations' },
          { name: 'Dishoom', cuisine: 'Indian', price: 18, dish: 'Lamb Biryani', addr: 'Covent Garden' }
        ],
        dinner: [
          { name: 'Sketch', cuisine: 'Fine Dining', price: 180, dish: 'Tasting Menu', addr: 'Mayfair' },
          { name: 'The Fat Duck', cuisine: 'Molecular Gastronomy', price: 200, dish: '3-Michelin Tasting', addr: 'Bray' }
        ]
      },
      weather: {
        spring: 'Cool, 8-15°C, rainy',
        summer: 'Mild, 15-22°C, crowded',
        fall: 'Cool, 8-16°C, dry',
        winter: 'Cold, 2-8°C, rainy'
      }
    }
  }
};

function generateTravelPlan(formData) {
  const dest = formData.destination?.toLowerCase() || 'paris';
  const destData = travelData.destinations[dest];

  if (!destData) {
    throw new Error(`Destination ${formData.destination} not found`);
  }

  const startDate = new Date(formData.startDate);
  const endDate = new Date(formData.endDate);
  const nights = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));

  return {
    summary: {
      destination: formData.destination,
      origin: formData.origin,
      duration: `${nights} nights`,
      travelers: `${formData.numberOfAdults} adults${formData.numberOfChildren ? ', ' + formData.numberOfChildren + ' children' : ''}`,
      budgetLevel: formData.budgetLevel,
      totalBudget: formData.estimatedTotal
    },

    dayByDayItinerary: generateItinerary(destData, nights, formData),
    hotelRecommendations: generateHotels(destData, formData),
    restaurantGuide: generateRestaurants(destData, nights, formData),
    budgetBreakdown: generateBudget(formData, destData, nights),
    packingList: generatePackingList(formData, destData),
    transportGuide: generateTransportGuide(dest, formData),
    culturalTips: generateCulturalTips(dest, destData),
    hiddenGems: generateHiddenGems(dest),
    preTripsChecklist: generateChecklist(formData, destData),
    emergencyInfo: generateEmergencyInfo(destData, formData),
    weatherTips: generateWeatherTips(startDate, destData),
    moneyGuide: generateMoneyGuide(destData)
  };
}

function generateItinerary(destData, nights, formData) {
  const activities = destData.activities;
  const itinerary = [];

  for (let day = 1; day <= Math.min(nights, 7); day++) {
    const mustSee = activities.filter(a => a.type === 'must-see');
    const optional = activities.filter(a => a.type === 'optional');

    itinerary.push({
      day,
      morning: {
        activity: mustSee[0]?.name || 'Local exploration',
        time: '8:00 AM - 12:00 PM',
        details: mustSee[0] || { fee: 0, hours: 'Flexible' }
      },
      afternoon: {
        activity: mustSee[1]?.name || 'Lunch break',
        time: '1:00 PM - 5:00 PM',
        details: mustSee[1] || { fee: 0 }
      },
      evening: {
        activity: mustSee[2]?.name || 'Dinner',
        time: '6:00 PM - 10:00 PM',
        details: mustSee[2] || { fee: 0 }
      }
    });
  }

  return itinerary;
}

function generateHotels(destData, formData) {
  const budgetLevel = formData.budgetLevel?.toLowerCase() || 'mid-range';
  const hotels = [];

  // Budget option
  if (destData.hotels.budget) {
    hotels.push({
      rank: '★ Budget Pick',
      ...destData.hotels.budget,
      perNight: `${destData.currency} ${destData.hotels.budget.price}`,
      whyGood: 'Best value, basic amenities, central location'
    });
  }

  // Mid-range
  if (destData.hotels.midrange) {
    hotels.push({
      rank: '★★★ Mid-Range',
      ...destData.hotels.midrange,
      perNight: `${destData.currency} ${destData.hotels.midrange.price}`,
      whyGood: 'Comfort, good amenities, excellent location'
    });
  }

  // Luxury
  if (destData.hotels.luxury) {
    hotels.push({
      rank: '★★★★★ Luxury',
      ...destData.hotels.luxury,
      perNight: `${destData.currency} ${destData.hotels.luxury.price}`,
      whyGood: 'Premium experience, iconic property, world-class service'
    });
  }

  return hotels;
}

function generateRestaurants(destData, nights, formData) {
  const meals = [];
  for (let day = 1; day <= Math.min(nights, 7); day++) {
    meals.push({
      day,
      breakfast: destData.restaurants.breakfast[day % destData.restaurants.breakfast.length],
      lunch: destData.restaurants.lunch[day % destData.restaurants.lunch.length],
      dinner: destData.restaurants.dinner[day % destData.restaurants.dinner.length]
    });
  }
  return meals;
}

function generateBudget(formData, destData, nights) {
  const totalBudget = parseFloat(formData.estimatedTotal) || 3000;
  const numTravelers = parseInt(formData.numberOfAdults) + (parseInt(formData.numberOfChildren) || 0);

  const hotelPrice = destData.hotels.midrange.price * nights;
  const flightPerPerson = destData.flights.avgPrice * 2; // Round trip
  const flightTotal = flightPerPerson * numTravelers;
  const foodDaily = (formData.mealBudgetDay || 50) * nights;
  const activities = totalBudget * 0.2;
  const transport = totalBudget * 0.1;
  const shopping = totalBudget * 0.1;
  const emergency = totalBudget * 0.05;

  return {
    currency: destData.currency,
    breakdown: [
      { category: 'Flights', amount: flightTotal, percentage: '25%' },
      { category: 'Accommodation', amount: hotelPrice, percentage: '30%' },
      { category: 'Food & Dining', amount: foodDaily, percentage: '20%' },
      { category: 'Activities & Tours', amount: activities, percentage: '10%' },
      { category: 'Local Transport', amount: transport, percentage: '7%' },
      { category: 'Shopping & Misc', amount: shopping, percentage: '6%' },
      { category: 'Emergency Buffer', amount: emergency, percentage: '2%' }
    ],
    totalBudget,
    perPersonPerDay: (totalBudget / (nights * numTravelers)).toFixed(2),
    dailyAverage: (totalBudget / nights).toFixed(2)
  };
}

function generatePackingList(formData, destData) {
  return {
    clothing: [
      'Comfortable walking shoes',
      'Casual daytime outfits (5-7 pieces)',
      'Evening wear (1-2 nicer pieces)',
      'Underwear & socks',
      'Sleepwear',
      'Weather-appropriate jacket',
      'Comfortable pants/shorts'
    ],
    electronics: [
      'Phone & charger',
      'Portable power bank',
      'Universal power adapter',
      'Camera/GoPro (optional)',
      'Headphones',
      'Laptop/tablet (optional)',
      'Universal USB cables'
    ],
    documents: [
      'Passport (valid for 6+ months)',
      'Travel insurance documents',
      'Flight confirmations',
      'Hotel reservations',
      'Visa (if required)',
      'Copies of important documents',
      'Emergency contact list'
    ],
    toiletries: [
      'Toothbrush & toothpaste',
      'Deodorant',
      'Shampoo & conditioner',
      'Skincare products',
      'Prescription medications',
      'First aid kit',
      'Sunscreen & lip balm'
    ],
    misc: [
      'Wallet & travel money',
      'Credit/debit cards',
      'Phone SIM card',
      'Luggage locks',
      'Day backpack',
      'Reusable water bottle',
      'Travel guidebook'
    ]
  };
}

function generateTransportGuide(destination, formData) {
  const guides = {
    paris: {
      apps: ['Google Maps', 'RATP (Metro)', 'Citymapper'],
      metro: 'Paris Metro - €2.15 per ticket, €16.90 for 10 pack',
      taxi: 'Approved cabs: Taxis Bleus, Taxi G7 - Starting €3.50 + €1.20/km',
      scamAlert: 'Avoid unofficial taxis, use official ranks or apps',
      simCard: 'Orange, SFR, Bouygues - €20/month basic plans'
    },
    tokyo: {
      apps: ['Google Maps', 'Suica/Pasmo (IC card)', 'Yahoo Transit'],
      metro: 'Tokyo Metro/JR - Single ride ¥170-310, 24h pass ¥700-900',
      taxi: 'Metered taxis - Starting ¥500 + ¥100/km after 2km',
      scamAlert: 'Taxis are generally honest, but confirm price before entering',
      simCard: 'SoftBank, Docomo, au - ¥2000/month or pocket WiFi rental'
    },
    dubai: {
      apps: ['Google Maps', 'RTA Nol (Metro card)', 'Uber/Careem'],
      metro: 'Dubai Metro - AED 2.50-4.50, Day pass AED 20',
      taxi: 'Official white taxis - AED 1.75 base + AED 1.76/km',
      scamAlert: 'Unofficial taxis may overcharge, use app-based services',
      simCard: 'Etisalat, du - AED 50-100/month basic plans'
    },
    london: {
      apps: ['Citymapper', 'TfL Go', 'Google Maps'],
      metro: 'London Underground - £1.75-2.80, Day cap £5.25',
      taxi: 'Licensed Black Cabs - Starting £2.40 + £2.40/mile',
      scamAlert: 'Avoid unlicensed minicabs, use official cabs or Uber',
      simCard: 'Vodafone, O2, EE - £15-20/month basic plans'
    }
  };

  return guides[destination.toLowerCase()] || guides.paris;
}

function generateCulturalTips(destination, destData) {
  const tips = {
    paris: {
      dresCode: 'Smart casual, comfortable but stylish. Avoid athletic wear in restaurants',
      tipping: '5-10% optional, not expected, round up in cafés',
      offensive: 'Don\'t be loud, respect personal space, learn basic French phrases',
      areasToAvoid: 'Avoid 18th arrondissement late night, southern suburbs after dark',
      safetyScore: 8.5,
      general: 'Paris is generally very safe, excellent public transport, high tourist infrastructure'
    },
    tokyo: {
      dresCode: 'Smart casual. Remove shoes indoors. Avoid revealing clothing',
      tipping: 'NOT customary - considered rude. Never tip in Japan',
      offensive: 'Pointing, loud conversation, eating while walking, standing on the left on escalators',
      areasToAvoid: 'Generally very safe. Avoid Roppongi late night for drunk tourists',
      safetyScore: 9.5,
      general: 'Extremely safe, excellent public transport, respectful culture'
    },
    dubai: {
      dresCode: 'Modest - no short shorts/tank tops in public. Respect Islamic culture',
      tipping: '10-15% in upscale restaurants, 5% in casual eateries, not required',
      offensive: 'Public displays of affection, criticism of rulers, public intoxication',
      areasToAvoid: 'Generally safe. Avoid slums. Women should avoid walking alone very late',
      safetyScore: 8.8,
      general: 'Very safe, modern infrastructure, strict laws - follow them'
    },
    london: {
      dresCode: 'Smart casual. West End requires more formal wear',
      tipping: '10-15% in restaurants (often added to bill), not required',
      offensive: 'Queue jumping, loud behavior, not saying please/thank you',
      areasToAvoid: 'Generally safe. Avoid Brixton, Peckham very late night',
      safetyScore: 8.0,
      general: 'Safe major city, diverse culture, excellent infrastructure'
    }
  };

  return tips[destination.toLowerCase()] || tips.paris;
}

function generateHiddenGems(destination) {
  const gems = {
    paris: [
      {
        name: 'Père Lachaise Cemetery',
        desc: 'Historic cemetery with famous graves, beautiful monuments, less crowded',
        hoursOpen: '8:00 AM - 5:30 PM',
        entry: 'Free',
        howToGetThere: 'Metro Line 2 or 3 to Père Lachaise station'
      },
      {
        name: 'Canal Saint-Martin',
        desc: 'Picturesque canal, local vibe, great for picnics, street art',
        hoursOpen: '24/7',
        entry: 'Free',
        howToGetThere: 'Metro to Jaurès or République station'
      },
      {
        name: 'Sainte-Chapelle Church',
        desc: 'Stunning stained glass windows, less crowded than Notre-Dame',
        hoursOpen: '9:00 AM - 7:00 PM',
        entry: '€11',
        howToGetThere: 'RER B to Saint-Michel, 5-minute walk'
      }
    ],
    tokyo: [
      {
        name: 'Tsukiji Outer Market',
        desc: 'Fresh sushi, street food, local energy, less touristy than inner market',
        hoursOpen: '5:00 AM - 12:00 PM',
        entry: 'Free (pay per item)',
        howToGetThere: 'Oedo/Hibiya Line to Tsukiji-shijo station'
      },
      {
        name: 'Yanaka District',
        desc: 'Vintage Tokyo charm, traditional shops, cozy cafés, temple',
        hoursOpen: '24/7',
        entry: 'Free',
        howToGetThere: 'Chiyoda Line to Nezu station, walk 10 mins'
      },
      {
        name: 'Teamlab Borderless',
        desc: 'Immersive digital art, mind-bending installations, Instagram gold',
        hoursOpen: '10:00 AM - 7:00 PM',
        entry: '¥3,200',
        howToGetThere: 'Yurikamome Line to Ariake station'
      }
    ],
    dubai: [
      {
        name: 'Al Fahidi Historical District',
        desc: 'Old Dubai charm, traditional wind towers, local culture, museums',
        hoursOpen: '9:00 AM - 9:00 PM',
        entry: 'Free to walk, museums ​​AED 3-10',
        howToGetThere: 'Metro Red Line to Al Fahidi station'
      },
      {
        name: 'Hatta Dam & Wadi',
        desc: 'Mountain landscape, scenic drive, hiking, away from city crowds',
        hoursOpen: '24/7',
        entry: 'Free',
        howToGetThere: 'Rental car or organized tour from city (1.5 hours)'
      },
      {
        name: 'Gold Souk at Night',
        desc: 'Shimmering gold jewelry, bustling market, amazing bargains',
        hoursOpen: '10:00 AM - 10:00 PM',
        entry: 'Free to browse',
        howToGetThere: 'Metro Red Line to Gold Souk station'
      }
    ],
    london: [
      {
        name: 'Leadenhall Market',
        desc: 'Historic covered market, cobbled streets, Victorian charm',
        hoursOpen: '10:00 AM - 6:00 PM',
        entry: 'Free',
        howToGetThere: 'District Line to Bank, walk 5 mins'
      },
      {
        name: 'Camden Market',
        desc: 'Vintage shops, street food, punk culture, weekend vibes',
        hoursOpen: '10:00 AM - 6:00 PM',
        entry: 'Free',
        howToGetThere: 'Northern Line to Camden Town'
      },
      {
        name: 'Hampstead Heath',
        desc: 'Wild heathland, panoramic views, ponds, far from tourist crowds',
        hoursOpen: '24/7',
        entry: 'Free',
        howToGetThere: 'Northern Line to Hampstead station'
      }
    ]
  };

  return gems[destination.toLowerCase()] || gems.paris;
}

function generateChecklist(formData, destData) {
  return [
    '✓ Apply for visa (if required) - Check 6-8 weeks before',
    '✓ Book travel insurance - Compare at least 3 providers',
    '✓ Confirm vaccinations needed - Visit travel clinic 4-6 weeks prior',
    '✓ Exchange currency - Get best rates at bank, not airport',
    '✓ Confirm all bookings - Hotel, flights, activities',
    '✓ Notify bank/credit card company - Avoid fraud blocks',
    '✓ Download offline maps - Google Maps, Maps.me',
    '✓ Save emergency contacts - Embassy, insurance, local hospitals',
    '✓ Make copies of documents - Store separately from originals',
    '✓ Check luggage limits - Avoid overpacking fees',
    '✓ Arrange airport transfers - Book accommodation pickup',
    '✓ Check outlet compatibility - Universal adapter might be needed'
  ];
}

function generateEmergencyInfo(destData, formData) {
  return {
    emergencyNumber: destData.emergencyNumber,
    hospitals: destData.hospitals.slice(0, 3),
    pharmacies: ['Major pharmacies near accommodation - Ask at hotel reception'],
    embassy: `Embassy of ${formData.passportCountry || 'Your Country'} - Check embassy.gov for address`,
    insuranceEmergencyLine: 'Contact info from your insurance policy',
    localPoliceNonEmergency: 'Included in destination-specific guides',
    poisonControl: 'Available through emergency number',
    tips: [
      'Save all emergency numbers in phone before arriving',
      'Know location of nearest hospital to accommodation',
      'Register with embassy if traveling for extended period',
      'Keep insurance documents easily accessible'
    ]
  };
}

function generateWeatherTips(startDate, destData) {
  const month = startDate.getMonth();
  let season = 'spring';
  if (month >= 5 && month <= 7) season = 'summer';
  else if (month >= 8 && month <= 10) season = 'fall';
  else if (month >= 11 || month === 0) season = 'winter';

  const weatherInfo = destData.weather[season];

  return {
    expectedCondition: weatherInfo,
    packingSpecifics: {
      summer: ['Light clothing', 'Sunscreen SPF 50+', 'Hat/sunglasses', 'Light scarf'],
      winter: ['Warm coat', 'Layers', 'Gloves', 'Warm socks'],
      spring: ['Light jacket', 'Umbrella', 'Layers', 'Comfortable walking shoes'],
      fall: ['Sweater', 'Light jacket', 'Comfortable shoes', 'Optional umbrella']
    }[season],
    bestTimeToVisit: 'Spring (April-May) or Fall (September-October) for mild weather and fewer crowds'
  };
}

function generateMoneyGuide(destData) {
  return {
    currency: destData.currency,
    bestWayToCarryMoney: [
      '50% credit/debit card (most accepted)',
      '30% cash (for small purchases, tips)',
      '20% backup card (emergency only)',
      'ATMs are usually safe and have best rates'
    ],
    atmTips: [
      'Use ATMs in malls or bank branches (safer)',
      'Withdraw larger amounts to save on fees',
      'Notify bank before traveling',
      'Avoid ATMs in remote areas'
    ],
    exchangeAdvice: [
      'Exchange money at bank before trip or at ATM',
      'Airport rates typically are 5-10% worse',
      'Credit cards usually offer best exchange rates',
      'Avoid currency exchange shops (high commissions)'
    ],
    scamAlert: 'NEVER agree to Dynamic Currency Conversion - insist on local currency payment',
    tippingGuide: 'See cultural tips section for destination-specific tipping customs'
  };
}

module.exports = { generateTravelPlan };
