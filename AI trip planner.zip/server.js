const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const https = require('https');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
require('dotenv').config();
const { generateTravelPlan } = require('./travelPlanner');

const app = express();
const PORT = process.env.PORT || 3000;
const HTTPS_PORT = process.env.HTTPS_PORT || 3443;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const SSL_KEY_PATH = process.env.SSL_KEY_PATH;
const SSL_CERT_PATH = process.env.SSL_CERT_PATH;
const FORCE_HTTPS = String(process.env.FORCE_HTTPS || 'false').toLowerCase() === 'true';

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Respect reverse proxy headers when deployed behind nginx/cloud load balancers.
app.set('trust proxy', true);

// Optional redirect to HTTPS. Useful in production when SSL is terminated at a proxy.
if (FORCE_HTTPS) {
  app.use((req, res, next) => {
    const isSecure = req.secure || req.get('x-forwarded-proto') === 'https';
    if (isSecure) {
      return next();
    }

    const host = req.get('host') || '';
    const hostname = host.split(':')[0];
    const targetHost = SSL_KEY_PATH && SSL_CERT_PATH ? `${hostname}:${HTTPS_PORT}` : host;
    return res.redirect(301, `https://${targetHost}${req.originalUrl}`);
  });
}

// Home route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API route to generate travel plan
app.post('/api/generate-plan', (req, res) => {
  try {
    const travelData = req.body;
    const plan = generateTravelPlan(travelData);
    res.json({ success: true, plan });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// API route to get Google Maps API key
app.get('/api/maps-key', (req, res) => {
  const mapsKey = process.env.GOOGLE_MAPS_API_KEY || '';
  res.json({ key: mapsKey });
});

// AI Chat route with Gemini API
app.post('/api/ai-chat', async (req, res) => {
  try {
    const { message, conversationHistory } = req.body;

    if (!GEMINI_API_KEY) {
      return res.status(400).json({ 
        success: false, 
        error: 'Gemini API key not configured. Please set GEMINI_API_KEY in .env' 
      });
    }

    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + GEMINI_API_KEY, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `You are a professional travel assistant helping users plan their trips. Be friendly, informative, and concise. 
                
Context: The user is using TravelPro, a personalized travel planning application. Help them with travel advice, destination information, cultural tips, or any travel-related questions.

User message: ${message}`
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 500,
        }
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error?.message || 'Gemini API request failed');
    }
    
    if (data.candidates && data.candidates[0]?.content?.parts?.[0]?.text) {
      const aiResponse = data.candidates[0].content.parts[0].text;
      res.json({ success: true, response: aiResponse });
    } else {
      throw new Error('Invalid response from Gemini API');
    }
  } catch (error) {
    console.error('AI Chat Error:', error);
    res.status(400).json({ success: false, error: error.message });
  }
});

if (SSL_KEY_PATH && SSL_CERT_PATH && fs.existsSync(SSL_KEY_PATH) && fs.existsSync(SSL_CERT_PATH)) {
  const credentials = {
    key: fs.readFileSync(SSL_KEY_PATH),
    cert: fs.readFileSync(SSL_CERT_PATH)
  };

  https.createServer(credentials, app).listen(HTTPS_PORT, () => {
    console.log(`🔒 Travel Planner running on https://localhost:${HTTPS_PORT}`);
  });

  // Keep HTTP available for redirect or local fallback.
  app.listen(PORT, () => {
    console.log(`🌍 HTTP endpoint running on http://localhost:${PORT}`);
  });
} else {
  app.listen(PORT, () => {
    console.log(`🌍 Travel Planner running on http://localhost:${PORT}`);
    console.log('ℹ️ HTTPS is disabled. Set SSL_KEY_PATH and SSL_CERT_PATH in .env to enable HTTPS.');
  });
}
