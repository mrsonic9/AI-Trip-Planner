// Form submission and plan generation
document.getElementById('travelForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    // Collect form data
    const formData = {
        destination: document.getElementById('destination').value,
        origin: document.getElementById('origin').value,
        startDate: document.getElementById('startDate').value,
        endDate: document.getElementById('endDate').value,
        groupType: document.getElementById('groupType').value,
        numberOfAdults: parseInt(document.getElementById('numberOfAdults').value),
        numberOfChildren: parseInt(document.getElementById('numberOfChildren').value),
        budgetLevel: document.getElementById('budgetLevel').value,
        estimatedTotal: parseFloat(document.getElementById('estimatedTotal').value),
        currency: document.getElementById('currency').value,
        mealBudgetDay: parseFloat(document.getElementById('mealBudgetDay').value),
        accommodationType: document.getElementById('accommodationType').value,
        tripPace: document.getElementById('tripPace').value,
        cuisinePreference: document.getElementById('cuisinePreference').value,
        dietaryRestriction: document.getElementById('dietaryRestriction').value,
        passportCountry: document.getElementById('passportCountry').value,
        visaStatus: document.getElementById('visaStatus').value,
        accessibilityNeeds: document.getElementById('accessibilityNeeds').value
    };

    try {
        // Show loading state
        const formSection = document.getElementById('formSection');
        const outputSection = document.getElementById('outputSection');
        formSection.style.opacity = '0.5';
        formSection.style.pointerEvents = 'none';
        
        // Send to server
        const response = await fetch('/api/generate-plan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        const result = await response.json();

        if (result.success) {
            displayPlan(result.plan, formData);
            formSection.style.display = 'none';
            outputSection.style.display = 'block';
            window.scrollTo(0, 0);
        } else {
            alert('Error: ' + result.error);
            formSection.style.opacity = '1';
            formSection.style.pointerEvents = 'auto';
        }
    } catch (error) {
        alert('Error generating plan: ' + error.message);
        document.getElementById('formSection').style.opacity = '1';
        document.getElementById('formSection').style.pointerEvents = 'auto';
    }
});

function displayPlan(plan, formData) {
    const output = document.getElementById('planOutput');
    let html = '';

    // 1. Summary Section
    html += `
        <div class="plan-section">
            <h2>✈️ Trip Summary</h2>
            <div class="summary-box">
                <p><strong>Destination:</strong> ${plan.summary.destination}</p>
                <p><strong>From:</strong> ${plan.summary.origin}</p>
                <p><strong>Duration:</strong> ${plan.summary.duration}</p>
                <p><strong>Travelers:</strong> ${plan.summary.travelers}</p>
                <p><strong>Budget Level:</strong> ${plan.summary.budgetLevel}</p>
                <p><strong>Total Budget:</strong> ${plan.summary.totalBudget} ${plan.budgetBreakdown.currency}</p>
            </div>
        </div>
    `;

    // 2. Day-by-Day Itinerary
    html += `<div class="plan-section">
        <h2>📅 Day-by-Day Itinerary</h2>`;
    
    plan.dayByDayItinerary.forEach(day => {
        html += `
            <div class="activity-card">
                <h4>Day ${day.day}</h4>
                <div class="details">
                    <div>
                        <strong>🌅 Morning (${day.morning.time})</strong>
                        <p>${day.morning.activity}</p>
                        ${day.morning.details.fee ? `<p>Fee: ${day.morning.details.fee}</p>` : ''}
                        ${day.morning.details.hours ? `<p>Hours: ${day.morning.details.hours}</p>` : ''}
                    </div>
                    <div>
                        <strong>☀️ Afternoon (${day.afternoon.time})</strong>
                        <p>${day.afternoon.activity}</p>
                        ${day.afternoon.details.fee ? `<p>Fee: ${day.afternoon.details.fee}</p>` : ''}
                    </div>
                    <div>
                        <strong>🌆 Evening (${day.evening.time})</strong>
                        <p>${day.evening.activity}</p>
                        ${day.evening.details.fee ? `<p>Fee: ${day.evening.details.fee}</p>` : ''}
                    </div>
                </div>
            </div>
        `;
    });
    html += `</div>`;

    // 3. Hotel Recommendations
    html += `<div class="plan-section">
        <h2>🏨 Top Hotel Recommendations</h2>
        <table>
            <tr>
                <th>Rating</th>
                <th>Name</th>
                <th>Location</th>
                <th>Price/Night</th>
                <th>Why Perfect</th>
            </tr>`;
    
    plan.hotelRecommendations.forEach(hotel => {
        html += `
            <tr>
                <td>${hotel.rank}</td>
                <td><strong>${hotel.name}</strong></td>
                <td>${hotel.addr}</td>
                <td>${hotel.perNight}</td>
                <td>${hotel.whyGood}</td>
            </tr>
        `;
    });
    html += `</table></div>`;

    // 4. Restaurant Guide
    html += `<div class="plan-section">
        <h2>🍽️ Restaurant Guide</h2>`;
    
    plan.restaurantGuide.forEach(dayMeal => {
        html += `
            <h3>Day ${dayMeal.day}</h3>
            <table>
                <tr>
                    <th>Meal</th>
                    <th>Restaurant</th>
                    <th>Cuisine</th>
                    <th>Price/Person</th>
                    <th>Must-Order</th>
                    <th>Address</th>
                </tr>
                <tr>
                    <td><strong>Breakfast</strong></td>
                    <td>${dayMeal.breakfast.name}</td>
                    <td>${dayMeal.breakfast.cuisine}</td>
                    <td>$${dayMeal.breakfast.price}</td>
                    <td>${dayMeal.breakfast.dish}</td>
                    <td>${dayMeal.breakfast.addr}</td>
                </tr>
                <tr>
                    <td><strong>Lunch</strong></td>
                    <td>${dayMeal.lunch.name}</td>
                    <td>${dayMeal.lunch.cuisine}</td>
                    <td>$${dayMeal.lunch.price}</td>
                    <td>${dayMeal.lunch.dish}</td>
                    <td>${dayMeal.lunch.addr}</td>
                </tr>
                <tr>
                    <td><strong>Dinner</strong></td>
                    <td>${dayMeal.dinner.name}</td>
                    <td>${dayMeal.dinner.cuisine}</td>
                    <td>$${dayMeal.dinner.price}</td>
                    <td>${dayMeal.dinner.dish}</td>
                    <td>${dayMeal.dinner.addr}</td>
                </tr>
            </table>
        `;
    });
    html += `</div>`;

    // 5. Budget Breakdown
    html += `<div class="plan-section">
        <h2>💰 Complete Budget Breakdown</h2>
        <table>
            <tr>
                <th>Category</th>
                <th>Amount (${plan.budgetBreakdown.currency})</th>
                <th>% of Budget</th>
            </tr>`;
    
    plan.budgetBreakdown.breakdown.forEach(item => {
        html += `
            <tr>
                <td><strong>${item.category}</strong></td>
                <td>${item.amount.toFixed(2)}</td>
                <td>${item.percentage}</td>
            </tr>
        `;
    });
    html += `
            <tr style="background: #f0f0f0; font-weight: bold;">
                <td>TOTAL</td>
                <td>${plan.budgetBreakdown.totalBudget}</td>
                <td>100%</td>
            </tr>
        </table>
        <p><strong>Daily Average Spend:</strong> ${plan.budgetBreakdown.currency} ${plan.budgetBreakdown.dailyAverage}</p>
        <p><strong>Per Person Per Day:</strong> ${plan.budgetBreakdown.currency} ${plan.budgetBreakdown.perPersonPerDay}</p>
        </div>`;

    // 6. Packing List
    html += `<div class="plan-section">
        <h2>🧳 Smart Packing List</h2>
        <h3>👕 Clothing</h3>
        <ul>`;
    plan.packingList.clothing.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <h3>📱 Electronics</h3>
        <ul>`;
    plan.packingList.electronics.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <h3>📄 Documents</h3>
        <ul>`;
    plan.packingList.documents.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <h3>🧴 Toiletries</h3>
        <ul>`;
    plan.packingList.toiletries.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <h3>🎒 Miscellaneous</h3>
        <ul>`;
    plan.packingList.misc.forEach(item => html += `<li>${item}</li>`);
    html += `</ul></div>`;

    // 7. Transport Guide
    html += `<div class="plan-section">
        <h2>🚌 Local Transport Guide</h2>
        <h3>Recommended Apps</h3>
        <p>${plan.transportGuide.apps.join(', ')}</p>
        <h3>Metro/Public Transit</h3>
        <p>${plan.transportGuide.metro}</p>
        <h3>Taxis</h3>
        <p>${plan.transportGuide.taxi}</p>
        <h3>⚠️ Scam Alert</h3>
        <p><strong>${plan.transportGuide.scamAlert}</strong></p>
        <h3>SIM Card Options</h3>
        <p>${plan.transportGuide.simCard}</p>
        </div>`;

    // 8. Cultural Tips
    html += `<div class="plan-section">
        <h2>🌏 Cultural Etiquette & Safety Tips</h2>
        <h3>👔 Dress Code</h3>
        <p>${plan.culturalTips.dresCode}</p>
        <h3>💵 Tipping Culture</h3>
        <p>${plan.culturalTips.tipping}</p>
        <h3>🚫 Things to Avoid</h3>
        <p>${plan.culturalTips.offensive}</p>
        <h3>⛔ Areas to Avoid</h3>
        <p>${plan.culturalTips.areasToAvoid}</p>
        <h3>🛡️ Safety Score</h3>
        <p><strong>${plan.culturalTips.safetyScore}/10</strong> - ${plan.culturalTips.general}</p>
        </div>`;

    // 9. Hidden Gems
    html += `<div class="plan-section">
        <h2>💎 Top 3 Hidden Gems</h2>`;
    
    plan.hiddenGems.forEach((gem, idx) => {
        html += `
            <div class="activity-card">
                <h4>${idx + 1}. ${gem.name}</h4>
                <p><strong>Description:</strong> ${gem.desc}</p>
                <p><strong>Hours:</strong> ${gem.hoursOpen}</p>
                <p><strong>Entry Fee:</strong> ${gem.entry}</p>
                <p><strong>How to Get There:</strong> ${gem.howToGetThere}</p>
            </div>
        `;
    });
    html += `</div>`;

    // 10. Pre-Trip Checklist
    html += `<div class="plan-section">
        <h2>✅ Pre-Trip Checklist (2 Weeks Before)</h2>
        <ul>`;
    
    plan.preTripsChecklist.forEach(item => html += `<li>${item}</li>`);
    html += `</ul></div>`;

    // 11. Emergency Information
    html += `<div class="plan-section">
        <h2>🚑 Emergency Information</h2>
        <h3>Emergency Numbers</h3>
        <p><strong>General Emergency:</strong> ${plan.emergencyInfo.emergencyNumber}</p>
        <h3>Hospitals Near You</h3>
        <ul>`;
    
    plan.emergencyInfo.hospitals.forEach(hospital => html += `<li>${hospital}</li>`);
    html += `</ul>
        <h3>Pharmacies</h3>
        <ul>`;
    
    plan.emergencyInfo.pharmacies.forEach(pharmacy => html += `<li>${pharmacy}</li>`);
    html += `</ul>
        <h3>Embassy/Consulate</h3>
        <p>${plan.emergencyInfo.embassy}</p>
        <h3>Insurance Emergency Line</h3>
        <p>${plan.emergencyInfo.insuranceEmergencyLine}</p>
        <h3>Important Tips</h3>
        <ul>`;
    
    plan.emergencyInfo.tips.forEach(tip => html += `<li>${tip}</li>`);
    html += `</ul></div>`;

    // 12. Weather Tips
    html += `<div class="plan-section">
        <h2>🌤️ Weather & What to Pack</h2>
        <h3>Expected Weather</h3>
        <p><strong>${plan.weatherTips.expectedCondition}</strong></p>
        <h3>Weather-Specific Packing</h3>
        <ul>`;
    
    plan.weatherTips.packingSpecifics.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <p><strong>💡 Pro Tip:</strong> ${plan.weatherTips.bestTimeToVisit}</p>
        </div>`;

    // 13. Money Guide
    html += `<div class="plan-section">
        <h2>💳 Money & Payments Guide</h2>
        <h3>Currency: ${plan.moneyGuide.currency}</h3>
        <h3>Best Way to Carry Money</h3>
        <ul>`;
    
    plan.moneyGuide.bestWayToCarryMoney.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <h3>ATM Tips</h3>
        <ul>`;
    
    plan.moneyGuide.atmTips.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <h3>Currency Exchange Advice</h3>
        <ul>`;
    
    plan.moneyGuide.exchangeAdvice.forEach(item => html += `<li>${item}</li>`);
    html += `</ul>
        <h3>⚠️ Scam Alert</h3>
        <p><strong>${plan.moneyGuide.scamAlert}</strong></p>
        </div>`;

    // Final footer
    html += `
        <div class="plan-section" style="text-align: center; background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);">
            <h3>🎉 Have an Amazing Trip!</h3>
            <p>This itinerary was specially crafted for you. Stay flexible, enjoy local experiences, and make memories!</p>
            <p style="margin-top: 20px; font-size: 0.9em; color: #999;">Generated on ${new Date().toLocaleDateString()}</p>
        </div>
    `;

    output.innerHTML = html;
}

function goBackToForm() {
    document.getElementById('outputSection').style.display = 'none';
    document.getElementById('formSection').style.display = 'block';
    window.scrollTo(0, 0);
}

function downloadPDF() {
    alert('PDF download feature will be available soon. You can use the Print function to save as PDF using your browser.');
}

// ============ AI CHAT FUNCTIONALITY ============

let map = null;
const destinations = {
    'Paris, France': { lat: 48.8566, lng: 2.3522 },
    'Tokyo, Japan': { lat: 35.6762, lng: 139.6503 },
    'Dubai, UAE': { lat: 25.2048, lng: 55.2708 },
    'London, UK': { lat: 51.5074, lng: -0.1278 }
};

// Load Google Maps API dynamically
async function loadGoogleMapsAPI() {
    try {
        const response = await fetch('/api/maps-key');
        const data = await response.json();
        if (data.key) {
            const script = document.getElementById('mapsScript');
            script.src = `https://maps.googleapis.com/maps/api/js?key=${data.key}&libraries=places`;
            script.async = true;
            script.defer = true;
        }
    } catch (error) {
        console.error('Error loading Maps API key:', error);
    }
}

// Initialize Google Map
function initializeMap() {
    const mapElement = document.getElementById('destinationMap');
    if (!mapElement || map) return;
    
    if (typeof google === 'undefined') {
        // Map not ready yet, try again
        setTimeout(initializeMap, 500);
        return;
    }

    map = new google.maps.Map(mapElement, {
        zoom: 13,
        center: destinations['Paris, France'],
        styles: [
            {
                "featureType": "all",
                "elementType": "labels.text.fill",
                "stylers": [{ "color": "#667eea" }]
            },
            {
                "featureType": "water",
                "elementType": "geometry.fill",
                "stylers": [{ "color": "#c3cfe2" }]
            }
        ]
    });
}

// Handle destination map selection
document.getElementById('mapDestination')?.addEventListener('change', (e) => {
    const destination = e.target.value;
    if (destination && destinations[destination] && map) {
        const coords = destinations[destination];
        map.setCenter(coords);
        new google.maps.Marker({
            position: coords,
            map: map,
            title: destination
        });
    }
});

// AI Chat Event Listeners
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendChatBtn');

sendBtn?.addEventListener('click', sendChatMessage);
chatInput?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendChatMessage();
    }
});

async function sendChatMessage() {
    const message = chatInput.value.trim();
    if (!message) return;

    // Add user message to chat
    addMessageToChat(message, 'user');
    chatInput.value = '';
    sendBtn.disabled = true;
    sendBtn.classList.add('loading');

    try {
        // Send to AI API
        const response = await fetch('/api/ai-chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });

        const result = await response.json();

        if (result.success) {
            addMessageToChat(result.response, 'ai');
        } else {
            addMessageToChat('Sorry, I encountered an error. Please make sure your Gemini API key is configured in the .env file.', 'ai');
        }
    } catch (error) {
        addMessageToChat('Error: Unable to connect. Please check your API configuration.', 'ai');
    } finally {
        sendBtn.disabled = false;
        sendBtn.classList.remove('loading');
        chatInput.focus();
    }
}

function addMessageToChat(text, sender) {
    const chatMessages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender === 'user' ? 'user-message' : 'ai-message'}`;

    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.innerHTML = sender === 'user' ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';

    const content = document.createElement('div');
    content.className = 'message-content';
    content.textContent = text;

    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    chatMessages.appendChild(messageDiv);
    
    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function setSuggestion(text) {
    document.getElementById('chatInput').value = text;
    sendChatMessage();
}

// Initialize map when page loads
window.addEventListener('load', () => {
    loadGoogleMapsAPI();
    setTimeout(initializeMap, 1000);
});
