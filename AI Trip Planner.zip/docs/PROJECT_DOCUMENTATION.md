# TravelPro Project Documentation

## Overview

TravelPro is an AI-powered travel planning web application that generates personalized trip plans, displays destination recommendations on Google Maps, and provides a Gemini-powered travel assistant.

The project is built as a lightweight full-stack app:

- **Frontend:** HTML, CSS, Vanilla JavaScript
- **Backend:** Node.js with Express
- **AI:** Google Gemini API
- **Maps:** Google Maps JavaScript API
- **Deployment:** Ubuntu server behind Nginx and PM2

## Core Goals

The application is designed to help a user:

1. Explore travel destinations visually.
2. Ask travel questions through an AI chat assistant.
3. Build a full itinerary using a guided planner form.
4. View budget, packing, transport, safety, weather, and money guidance.
5. Deploy a clean, professional travel-planning website on a public domain.

## User-Facing Sections

### 1. Home

The hero section introduces the product with a clear title, short value statement, and a call-to-action button that scrolls to the planner.

### 2. AI Chat

The AI section is split into two panels:

- **Left panel:** Google Maps with a destination selector
- **Right panel:** Gemini-powered chat interface

The user can either type a question or choose a suggestion button such as budget tips, safety tips, or packing tips.

### 3. Features

This section highlights the main planner benefits:

- Complete itineraries
- Hotel recommendations
- Dining guide
- Budget breakdown
- Packing list
- Travel tips

### 4. Destinations

This section presents the supported destinations as visual cards:

- Paris
- Tokyo
- Dubai
- London

Each card includes an image, short description, tag, and an action that jumps the user into the map experience.

### 5. Planner

The planner form collects all trip details needed to generate the travel plan:

- Destination and origin
- Start and end dates
- Traveler group details
- Budget and meal spending
- Trip pace and dining preferences
- Dietary restriction and accommodation type
- Passport country and visa status

After submission, the app renders the generated 12-section travel plan.

## System Architecture

### Frontend Flow

1. The user opens the landing page in the browser.
2. The page loads the hero, feature cards, destination cards, planner form, and AI assistant.
3. The browser loads `public/script.js` to attach event handlers.
4. Form submission sends JSON to `/api/generate-plan`.
5. Chat messages are sent to `/api/ai-chat`.
6. The Google Maps script is loaded dynamically after the backend returns the Maps API key.

### Backend Flow

1. `server.js` starts an Express server.
2. Static assets are served from the `public/` folder.
3. `/api/generate-plan` asks Gemini to produce structured JSON trip plans.
4. The backend normalizes and validates the generated JSON before returning it.
5. Gemini chat requests are also handled server-side.
6. Google Maps key is exposed through a controlled route for client-side map loading.

## Main Files

### [server.js](../server.js)

Handles Express setup, API routes, Gemini communication, AI-based plan generation, response normalization, and optional HTTPS support.

### [public/index.html](../public/index.html)

Defines the page structure: navigation, hero, AI section, features, destinations, planner form, output section, and footer.

### [public/style.css](../public/style.css)

Contains all visual styling, responsive rules, animations, AI section layout, cards, forms, and output formatting.

### [public/script.js](../public/script.js)

Manages form submission, travel plan rendering, AI chat behavior, Google Maps loading, destination selection, and UI interactions.

### [.env](../.env)

Stores server-side and deployment configuration such as API keys and ports.

## API Endpoints

### `GET /`

Serves the main application page.

### `POST /api/generate-plan`

Accepts travel form data and returns a complete generated trip plan.

Request body example:

```json
{
  "destination": "Paris",
  "origin": "London",
  "startDate": "2026-06-01",
  "endDate": "2026-06-07",
  "groupType": "Couple"
}
```

### `POST /api/ai-chat`

Sends a chat message to Gemini and returns the AI response.

Request body example:

```json
{
  "message": "Best budget tips for Tokyo?"
}
```

### `GET /api/maps-key`

Returns the Google Maps API key to the frontend so the map script can be loaded dynamically.

## Environment Variables

Use the `.env` file to configure the app:

```env
PORT=3000
GEMINI_API_KEY=your_gemini_key
GOOGLE_MAPS_API_KEY=your_maps_key
GEMINI_MODEL=gemini-2.5-flash
FORCE_HTTPS=false
HTTPS_PORT=3443
SSL_KEY_PATH=
SSL_CERT_PATH=
```

### Variable Notes

- `PORT`: Node application port
- `GEMINI_API_KEY`: Server-side Gemini key
- `GOOGLE_MAPS_API_KEY`: Maps JavaScript API key used in the browser
- `GEMINI_MODEL`: Gemini model name, configurable for future changes
- `FORCE_HTTPS`: Optional redirect behavior when SSL is handled by Node or a proxy
- `HTTPS_PORT`: Local HTTPS port when Node serves SSL directly
- `SSL_KEY_PATH` / `SSL_CERT_PATH`: File paths for local SSL certificate setup

## Local Development Setup

### Install Dependencies

```bash
npm install
```

### Start the App

```bash
npm start
```

### Open in Browser

```text
http://localhost:3000
```

## Production Deployment on Ubuntu / AWS

The production setup used for this project is:

1. Deploy the project on an Ubuntu EC2 server.
2. Run the Node app with PM2.
3. Use Nginx as a reverse proxy.
4. Point the domain or subdomain DNS to the server IP.
5. Use Certbot for HTTPS.

### Recommended Production Flow

1. Upload the project to the server.
2. Install Node.js, Nginx, and PM2.
3. Install dependencies with `npm install`.
4. Configure `.env` with production keys.
5. Start the app with PM2.
6. Configure Nginx to forward traffic to `127.0.0.1:3000`.
7. Add SSL with Certbot.
8. Restart PM2 after updates.

## How the Travel Plan is Generated

The planner works like this:

1. The user fills in the form.
2. `public/script.js` packages the form fields into JSON.
3. The browser sends the data to `/api/generate-plan`.
4. `server.js` sends a strict JSON-schema prompt to Gemini.
5. Gemini returns AI-generated travel plan JSON.
6. `server.js` normalizes the response to the app schema.
7. The frontend renders the plan into cards, tables, and lists.

## How the AI Chat Works

1. The user writes a message or clicks a suggestion button.
2. The browser sends the message to `/api/ai-chat`.
3. `server.js` validates the Gemini key.
4. The backend sends the request to the Gemini API.
5. The response is returned to the browser.
6. `public/script.js` formats and displays the answer in chat bubbles.

## How Google Maps Works

1. The frontend requests the Maps API key from `/api/maps-key`.
2. `public/script.js` dynamically injects the Google Maps script.
3. The map is initialized in the destination panel.
4. Selecting a destination changes the center and marker.
5. Clicking a destination card also jumps the map to that location.

## Supported Destinations

The app currently supports four destinations:

- Paris, France
- Tokyo, Japan
- Dubai, UAE
- London, UK

Each destination includes:

- itinerary logic
- hotel suggestions
- restaurant suggestions
- local transport guidance
- cultural tips
- emergency info
- weather suggestions
- money tips

## Troubleshooting

### Port Already in Use

If `npm start` fails with `EADDRINUSE`, another Node process is already using port 3000.

Fix:

```bash
pm2 restart travelpro
```

or stop the conflicting process before starting the server again.

### Gemini Error

If the chat returns a model or API error, check:

- The `GEMINI_API_KEY` value is valid
- The key starts with `AIza`
- The project has Gemini access enabled
- The model name in `GEMINI_MODEL` is available

### Maps Not Loading

If the map is blank or not working, check:

- `GOOGLE_MAPS_API_KEY` is valid
- Maps JavaScript API is enabled in Google Cloud
- The domain or localhost referrer is allowed

### Missing File or ENOENT Errors

If the server complains about missing files, confirm that all `public/` files exist on the deployed server and that the project path is correct.

### HTTPS Warning

If HTTPS is handled by Nginx, the Node app can run on HTTP internally. That is normal and expected.

## Customization Guide

### Add a New Destination

1. Add the destination option in `public/index.html`.
2. Add destination coordinates in `public/script.js` for map centering.
3. Add a destination card for visual discovery if needed.
4. Update Gemini prompt rules in `server.js` to improve destination-specific output quality.

### Update Styling

Change colors, spacing, or card layouts in `public/style.css`.

### Update AI Behavior

Edit the prompt in `server.js` inside the `/api/ai-chat` route.

### Update the Model

Set a different Gemini model by changing `GEMINI_MODEL` in `.env`.

## Security Notes

- Keep `GEMINI_API_KEY` server-side only.
- Restrict the Google Maps key by referrer and API scope.
- Do not commit `.env` to git.
- Use HTTPS in production.

## Project Strengths

- Clean full-stack separation
- Professional UI with responsive layout
- AI assistant integration
- Maps integration
- Detailed generated travel output
- Ready for hosting behind a real domain

## Suggested Next Improvements

1. Save generated plans to a database.
2. Add user authentication.
3. Support more destinations.
4. Add real-time weather and flight APIs.
5. Add PDF export without browser print.
6. Add richer markdown rendering in chat.

## Final Notes

This documentation covers how the project is structured, how it works, how to deploy it, and how to extend it safely.

If you change any API keys, server settings, or destination data later, update this document so it stays accurate.
