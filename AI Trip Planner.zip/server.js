const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const https = require('https');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const HTTPS_PORT = process.env.HTTPS_PORT || 3443;
const SSL_KEY_PATH = process.env.SSL_KEY_PATH;
const SSL_CERT_PATH = process.env.SSL_CERT_PATH;
const FORCE_HTTPS = String(process.env.FORCE_HTTPS || 'false').toLowerCase() === 'true';
const GEMINI_MODEL = String(process.env.GEMINI_MODEL || 'gemini-2.5-flash').trim();

function isValidGeminiKey(key) {
  if (!key) return false;
  const normalized = String(key).trim();
  if (!normalized) return false;
  if (normalized.toLowerCase().includes('place_your')) return false;
  if (normalized.toLowerCase().includes('paste_your')) return false;
  return normalized.startsWith('AIza');
}

function extractGeminiText(data) {
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

function stripCodeFences(text) {
  const trimmed = String(text || '').trim();
  if (trimmed.startsWith('```')) {
    return trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  }
  return trimmed;
}

function parseJsonFromText(text) {
  const cleaned = stripCodeFences(text);
  try {
    return JSON.parse(cleaned);
  } catch (_error) {
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start !== -1 && end !== -1 && end > start) {
      return JSON.parse(cleaned.slice(start, end + 1));
    }
    throw new Error('Gemini returned invalid JSON for travel plan');
  }
}

function asNumber(value, fallback = 0) {
  const num = Number(value);
  return Number.isFinite(num) ? num : fallback;
}

function asString(value, fallback = '') {
  return typeof value === 'string' && value.trim() ? value.trim() : fallback;
}

function asArray(value, fallback = []) {
  return Array.isArray(value) ? value : fallback;
}

function normalizePlanShape(rawPlan, formData) {
  const startDate = new Date(formData.startDate);
  const endDate = new Date(formData.endDate);
  const nightsCalc = Math.max(1, Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)));
  const nights = Math.min(nightsCalc, 7);
  const adults = Math.max(1, asNumber(formData.numberOfAdults, 1));
  const children = Math.max(0, asNumber(formData.numberOfChildren, 0));
  const totalTravelers = adults + children;
  const totalBudget = asNumber(formData.estimatedTotal, 3000);

  const summary = rawPlan.summary || {};
  const budget = rawPlan.budgetBreakdown || {};

  const itinerary = asArray(rawPlan.dayByDayItinerary)
    .slice(0, nights)
    .map((d, i) => ({
      day: asNumber(d?.day, i + 1),
      morning: {
        time: asString(d?.morning?.time, '8:30 AM - 12:00 PM'),
        activity: asString(d?.morning?.activity, 'Local morning exploration'),
        details: {
          fee: asNumber(d?.morning?.details?.fee, 0),
          hours: asString(d?.morning?.details?.hours, 'Flexible')
        }
      },
      afternoon: {
        time: asString(d?.afternoon?.time, '1:00 PM - 5:00 PM'),
        activity: asString(d?.afternoon?.activity, 'Neighborhood discovery and lunch'),
        details: {
          fee: asNumber(d?.afternoon?.details?.fee, 0),
          hours: asString(d?.afternoon?.details?.hours, 'Flexible')
        }
      },
      evening: {
        time: asString(d?.evening?.time, '6:30 PM - 10:00 PM'),
        activity: asString(d?.evening?.activity, 'Evening walk and local dinner'),
        details: {
          fee: asNumber(d?.evening?.details?.fee, 0),
          hours: asString(d?.evening?.details?.hours, 'Flexible')
        }
      }
    }));

  const hotelRecommendations = asArray(rawPlan.hotelRecommendations).map((h, i) => ({
    rank: asString(h?.rank, `${i + 1}`),
    name: asString(h?.name, 'Recommended Hotel'),
    addr: asString(h?.addr, 'Central Area'),
    perNight: asString(h?.perNight, `${asString(budget.currency, 'USD')} ${asNumber(h?.price, 100)}`),
    whyGood: asString(h?.whyGood, 'Recommended based on your preferences and budget')
  }));

  const restaurantGuide = asArray(rawPlan.restaurantGuide)
    .slice(0, nights)
    .map((r, i) => ({
      day: asNumber(r?.day, i + 1),
      breakfast: {
        name: asString(r?.breakfast?.name, 'Local Cafe'),
        cuisine: asString(r?.breakfast?.cuisine, 'Local'),
        price: asNumber(r?.breakfast?.price, 10),
        dish: asString(r?.breakfast?.dish, 'Chef Special'),
        addr: asString(r?.breakfast?.addr, 'City Center')
      },
      lunch: {
        name: asString(r?.lunch?.name, 'Popular Bistro'),
        cuisine: asString(r?.lunch?.cuisine, 'Local'),
        price: asNumber(r?.lunch?.price, 20),
        dish: asString(r?.lunch?.dish, 'House Favorite'),
        addr: asString(r?.lunch?.addr, 'City Center')
      },
      dinner: {
        name: asString(r?.dinner?.name, 'Evening Restaurant'),
        cuisine: asString(r?.dinner?.cuisine, 'Local'),
        price: asNumber(r?.dinner?.price, 35),
        dish: asString(r?.dinner?.dish, 'Signature Dish'),
        addr: asString(r?.dinner?.addr, 'City Center')
      }
    }));

  const totalBudgetNormalized = asNumber(budget.totalBudget, totalBudget);
  const budgetBreakdown = {
    currency: asString(budget.currency, formData.currency || 'USD'),
    breakdown: asArray(budget.breakdown).map((b) => ({
      category: asString(b?.category, 'Category'),
      amount: asNumber(b?.amount, 0),
      percentage: asString(b?.percentage, '0%')
    })),
    totalBudget: totalBudgetNormalized,
    dailyAverage: asString(budget.dailyAverage, (totalBudgetNormalized / nights).toFixed(2)),
    perPersonPerDay: asString(budget.perPersonPerDay, (totalBudgetNormalized / (nights * totalTravelers)).toFixed(2))
  };

  return {
    summary: {
      destination: asString(summary.destination, formData.destination || 'Destination'),
      origin: asString(summary.origin, formData.origin || 'Origin'),
      duration: asString(summary.duration, `${nights} nights`),
      travelers: asString(summary.travelers, `${adults} adults${children ? `, ${children} children` : ''}`),
      budgetLevel: asString(summary.budgetLevel, formData.budgetLevel || 'Mid-Range'),
      totalBudget: asNumber(summary.totalBudget, totalBudgetNormalized)
    },
    dayByDayItinerary: itinerary,
    hotelRecommendations,
    restaurantGuide,
    budgetBreakdown,
    packingList: {
      clothing: asArray(rawPlan?.packingList?.clothing, ['Comfortable outfits', 'Walking shoes']),
      electronics: asArray(rawPlan?.packingList?.electronics, ['Phone & charger', 'Power bank']),
      documents: asArray(rawPlan?.packingList?.documents, ['Passport', 'Insurance docs']),
      toiletries: asArray(rawPlan?.packingList?.toiletries, ['Toothbrush', 'Prescription medicines']),
      misc: asArray(rawPlan?.packingList?.misc, ['Travel adapter', 'Reusable water bottle'])
    },
    transportGuide: {
      apps: asArray(rawPlan?.transportGuide?.apps, ['Google Maps']),
      metro: asString(rawPlan?.transportGuide?.metro, 'Use local metro/bus day passes for savings.'),
      taxi: asString(rawPlan?.transportGuide?.taxi, 'Use official taxi apps to avoid overcharging.'),
      scamAlert: asString(rawPlan?.transportGuide?.scamAlert, 'Avoid unofficial taxis and currency conversion traps.'),
      simCard: asString(rawPlan?.transportGuide?.simCard, 'Buy SIM/eSIM at airport or official telecom stores.')
    },
    culturalTips: {
      dresCode: asString(rawPlan?.culturalTips?.dresCode, 'Dress comfortably and respectfully for local customs.'),
      tipping: asString(rawPlan?.culturalTips?.tipping, 'Tip according to local custom and service level.'),
      offensive: asString(rawPlan?.culturalTips?.offensive, 'Respect local customs and public behavior rules.'),
      areasToAvoid: asString(rawPlan?.culturalTips?.areasToAvoid, 'Avoid isolated areas late at night.'),
      safetyScore: asNumber(rawPlan?.culturalTips?.safetyScore, 8),
      general: asString(rawPlan?.culturalTips?.general, 'Stay alert in crowded places and keep valuables secure.')
    },
    hiddenGems: asArray(rawPlan.hiddenGems).map((g) => ({
      name: asString(g?.name, 'Hidden Gem'),
      desc: asString(g?.desc, 'A great local spot worth visiting.'),
      hoursOpen: asString(g?.hoursOpen, 'Flexible'),
      entry: asString(g?.entry, 'Varies'),
      howToGetThere: asString(g?.howToGetThere, 'Use local transit')
    })),
    cityVoices: asArray(rawPlan.cityVoices).map((v, i) => ({
      day: asNumber(v?.day, i + 1),
      phrase: asString(v?.phrase, 'Hello!'),
      meaning: asString(v?.meaning, 'A local greeting.'),
      context: asString(v?.context, 'Used in daily conversation.')
    })),
    preTripsChecklist: asArray(rawPlan.preTripsChecklist, ['Confirm bookings', 'Check documents', 'Buy insurance']),
    emergencyInfo: {
      emergencyNumber: asString(rawPlan?.emergencyInfo?.emergencyNumber, '112'),
      hospitals: asArray(rawPlan?.emergencyInfo?.hospitals, ['Major city hospital']),
      pharmacies: asArray(rawPlan?.emergencyInfo?.pharmacies, ['24/7 central pharmacy']),
      embassy: asString(rawPlan?.emergencyInfo?.embassy, 'Check embassy website for nearest office.'),
      insuranceEmergencyLine: asString(rawPlan?.emergencyInfo?.insuranceEmergencyLine, 'Use your insurer emergency hotline.'),
      tips: asArray(rawPlan?.emergencyInfo?.tips, ['Keep emergency contacts saved offline.'])
    },
    weatherTips: {
      expectedCondition: asString(rawPlan?.weatherTips?.expectedCondition, 'Check forecast 3 days before departure.'),
      packingSpecifics: asArray(rawPlan?.weatherTips?.packingSpecifics, ['Layered clothing', 'Comfortable shoes']),
      bestTimeToVisit: asString(rawPlan?.weatherTips?.bestTimeToVisit, 'Shoulder seasons usually offer better value.')
    },
    moneyGuide: {
      currency: asString(rawPlan?.moneyGuide?.currency, budgetBreakdown.currency),
      bestWayToCarryMoney: asArray(rawPlan?.moneyGuide?.bestWayToCarryMoney, ['Use a mix of card and small cash.']),
      atmTips: asArray(rawPlan?.moneyGuide?.atmTips, ['Use bank ATMs in busy areas.']),
      exchangeAdvice: asArray(rawPlan?.moneyGuide?.exchangeAdvice, ['Avoid airport exchange counters.']),
      scamAlert: asString(rawPlan?.moneyGuide?.scamAlert, 'Pay in local currency and avoid unofficial exchange deals.')
    }
  };
}

function buildTripPlanPrompt(formData) {
  return `You are a senior travel planner AI.

Create a fully AI-generated travel plan in JSON only (no markdown, no code fences, no explanation).
The plan must be practical, realistic, and budget-aware.

User input:
${JSON.stringify(formData, null, 2)}

Critical rules:
1) Budget must strongly affect results (hotels, dining, activities, transport style).
2) Day-by-day itinerary must be unique per day (no repeated same 3 places every day).
3) Restaurant suggestions should vary by day and fit meal budget.
4) Keep plan to max 7 days.
5) Add a fun section cityVoices with one local phrase per day.
6) Use numeric values for prices/fees where possible.

Return exactly this JSON schema:
{
  "summary": {
    "destination": "string",
    "origin": "string",
    "duration": "string",
    "travelers": "string",
    "budgetLevel": "string",
    "totalBudget": 0
  },
  "dayByDayItinerary": [
    {
      "day": 1,
      "morning": { "activity": "string", "time": "string", "details": { "fee": 0, "hours": "string" } },
      "afternoon": { "activity": "string", "time": "string", "details": { "fee": 0, "hours": "string" } },
      "evening": { "activity": "string", "time": "string", "details": { "fee": 0, "hours": "string" } }
    }
  ],
  "hotelRecommendations": [
    { "rank": "string", "name": "string", "addr": "string", "perNight": "string", "whyGood": "string" }
  ],
  "restaurantGuide": [
    {
      "day": 1,
      "breakfast": { "name": "string", "cuisine": "string", "price": 0, "dish": "string", "addr": "string" },
      "lunch": { "name": "string", "cuisine": "string", "price": 0, "dish": "string", "addr": "string" },
      "dinner": { "name": "string", "cuisine": "string", "price": 0, "dish": "string", "addr": "string" }
    }
  ],
  "budgetBreakdown": {
    "currency": "string",
    "breakdown": [
      { "category": "Flights", "amount": 0, "percentage": "string" },
      { "category": "Accommodation", "amount": 0, "percentage": "string" },
      { "category": "Food & Dining", "amount": 0, "percentage": "string" },
      { "category": "Activities & Tours", "amount": 0, "percentage": "string" },
      { "category": "Local Transport", "amount": 0, "percentage": "string" },
      { "category": "Shopping & Misc", "amount": 0, "percentage": "string" },
      { "category": "Emergency Buffer", "amount": 0, "percentage": "string" }
    ],
    "totalBudget": 0,
    "dailyAverage": "string",
    "perPersonPerDay": "string"
  },
  "packingList": {
    "clothing": ["string"],
    "electronics": ["string"],
    "documents": ["string"],
    "toiletries": ["string"],
    "misc": ["string"]
  },
  "transportGuide": {
    "apps": ["string"],
    "metro": "string",
    "taxi": "string",
    "scamAlert": "string",
    "simCard": "string"
  },
  "culturalTips": {
    "dresCode": "string",
    "tipping": "string",
    "offensive": "string",
    "areasToAvoid": "string",
    "safetyScore": 0,
    "general": "string"
  },
  "hiddenGems": [
    { "name": "string", "desc": "string", "hoursOpen": "string", "entry": "string", "howToGetThere": "string" }
  ],
  "cityVoices": [
    { "day": 1, "phrase": "string", "meaning": "string", "context": "string" }
  ],
  "preTripsChecklist": ["string"],
  "emergencyInfo": {
    "emergencyNumber": "string",
    "hospitals": ["string"],
    "pharmacies": ["string"],
    "embassy": "string",
    "insuranceEmergencyLine": "string",
    "tips": ["string"]
  },
  "weatherTips": {
    "expectedCondition": "string",
    "packingSpecifics": ["string"],
    "bestTimeToVisit": "string"
  },
  "moneyGuide": {
    "currency": "string",
    "bestWayToCarryMoney": ["string"],
    "atmTips": ["string"],
    "exchangeAdvice": ["string"],
    "scamAlert": "string"
  }
}`;
}

async function callGemini(prompt, options = {}) {
  const geminiKey = String(process.env.GEMINI_API_KEY || '').trim();

  if (!isValidGeminiKey(geminiKey)) {
    throw new Error('Invalid or missing GEMINI_API_KEY. Add a real Gemini key in .env and restart the server.');
  }

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${geminiKey}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: options.temperature ?? 0.65,
        topK: 40,
        topP: 0.95,
        maxOutputTokens: options.maxOutputTokens ?? 4096,
        responseMimeType: options.responseMimeType || 'text/plain'
      }
    })
  });

  const data = await response.json();

  if (!response.ok) {
    const apiMessage = data.error?.message || 'Gemini API request failed';
    const err = new Error(apiMessage);
    err.statusCode = response.status;
    throw err;
  }

  const text = extractGeminiText(data);
  if (!text) {
    throw new Error('Gemini returned an empty response');
  }

  return text;
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Respect reverse proxy headers when deployed behind nginx/cloud load balancers.
app.set('trust proxy', true);

// Optional redirect to HTTPS. Useful in production when SSL is terminated at a proxy.
if (FORCE_HTTPS) {
  app.use((req, res, next) => {
    const isSecure = req.secure || req.get('x-forwarded-proto') === 'https';
    if (isSecure) {
      return next();
    }

    const host = req.get('host') || '';
    const hostname = host.split(':')[0];
    const targetHost = SSL_KEY_PATH && SSL_CERT_PATH ? `${hostname}:${HTTPS_PORT}` : host;
    return res.redirect(301, `https://${targetHost}${req.originalUrl}`);
  });
}

// Home route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API route to generate travel plan using Gemini (AI-generated data)
app.post('/api/generate-plan', async (req, res) => {
  try {
    const formData = req.body;
    const prompt = buildTripPlanPrompt(formData);
    const rawText = await callGemini(prompt, {
      temperature: 0.6,
      maxOutputTokens: 16384,
      responseMimeType: 'text/plain'
    });

    const parsedPlan = parseJsonFromText(rawText);
    const plan = normalizePlanShape(parsedPlan, formData);

    res.json({ success: true, plan });
  } catch (error) {
    console.error('Generate Plan Error:', error);
    res.status(error.statusCode || 400).json({ success: false, error: error.message });
  }
});

// API route to get Google Maps API key
app.get('/api/maps-key', (req, res) => {
  const mapsKey = process.env.GOOGLE_MAPS_API_KEY || '';
  res.json({ key: mapsKey });
});

// AI Chat route with Gemini API
app.post('/api/ai-chat', async (req, res) => {
  try {
    const { message } = req.body;
    const chatPrompt = `You are a professional travel assistant helping users plan their trips. Be friendly, informative, and concise.

Context: The user is using TravelPro, a personalized travel planning application. Help them with travel advice, destination information, cultural tips, or any travel-related questions.

User message: ${message}`;

    const aiResponse = await callGemini(chatPrompt, {
      temperature: 0.7,
      maxOutputTokens: 700,
      responseMimeType: 'text/plain'
    });

    res.json({ success: true, response: aiResponse });
  } catch (error) {
    console.error('AI Chat Error:', error);
    res.status(error.statusCode || 400).json({ success: false, error: error.message });
  }
});

if (SSL_KEY_PATH && SSL_CERT_PATH && fs.existsSync(SSL_KEY_PATH) && fs.existsSync(SSL_CERT_PATH)) {
  const credentials = {
    key: fs.readFileSync(SSL_KEY_PATH),
    cert: fs.readFileSync(SSL_CERT_PATH)
  };

  https.createServer(credentials, app).listen(HTTPS_PORT, () => {
    console.log(`🔒 Travel Planner running on https://localhost:${HTTPS_PORT}`);
  });

  // Keep HTTP available for redirect or local fallback.
  app.listen(PORT, () => {
    console.log(`🌍 HTTP endpoint running on http://localhost:${PORT}`);
  });
} else {
  app.listen(PORT, () => {
    console.log(`🌍 Travel Planner running on http://localhost:${PORT}`);
    console.log('ℹ️ HTTPS is disabled. Set SSL_KEY_PATH and SSL_CERT_PATH in .env to enable HTTPS.');
  });
}
